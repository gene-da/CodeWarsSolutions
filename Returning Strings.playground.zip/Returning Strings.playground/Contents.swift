func TestStr (_ function: [Int], _ answer: [Int]) {
    print("Function:\t\(function)")
    print("Answer:\t\t\(answer)")
    if function == answer {
        print("PASSED\n")
    } else {
        print("FAILED\n")
    }
}

func digitize(_ num:Int) -> [Int] {
    return String(num).reversed().map({ $0.wholeNumberValue! })
}

TestStr(digitize(123), [3, 2, 1])
TestStr(digitize(348597), [7,9,5,8,4,3])
TestStr(digitize(35231),[1,3,2,5,3])
TestStr(digitize(23582357),[7,5,3,2,8,5,3,2])
TestStr(digitize(984764738),[8,3,7,4,6,7,4,8,9])
TestStr(digitize(45762893920),[0,2,9,3,9,8,2,6,7,5,4])
TestStr(digitize(548702838394),[4,9,3,8,3,8,2,0,7,8,4,5])
