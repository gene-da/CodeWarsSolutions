func evenOrOdd(_ number:Int) -> String {
    return number % 2 == 0 ? "Even" : "Odd"
}



evenOrOdd(2)
evenOrOdd(0)
evenOrOdd(7)
evenOrOdd(1)
evenOrOdd(-4)
evenOrOdd(-3)
