func squareSum(_ vals: [Int]) -> Int {
    return vals.map({ $0 * $0 }).reduce(0, +)
}

print(squareSum([1, 2, 3]))

squareSum([])             // 0
squareSum([1])            // 1
squareSum([1, 2])         // 5
squareSum([3, 4])         // 25
squareSum([-3, -4])       // 25
squareSum([1, 2, 3])      // 14
squareSum([5, 3, 4])      // 50
squareSum([-3, -4, 0])    // 25
squareSum([])             // 0
squareSum([1])            // 1
squareSum([1, 2])         // 5
squareSum([3, 4])         // 25
squareSum([-3, -4])       // 25
squareSum([1, 2, 3])      // 14
squareSum([5, 3, 4])      // 50
squareSum([-3, -4, 0])    // 25
