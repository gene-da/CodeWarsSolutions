func findDigit(_ num:Int, _ nth: Int) -> Int {
    let intArr: [Int] = String(abs(num)).map({ $0.wholeNumberValue! })
    if nth > intArr.count { return 0 }
    else if nth < 1 { return -1 }
    else { return intArr[intArr.count - nth] }
}

print(abs(-56))

print(findDigit(5673, 4))   //  5
print(findDigit(129, 2))    //  2
print(findDigit(-2825, 3))  //  8
print(findDigit(-456, 4))   //  0
print(findDigit(0, 20))     //  0
print(findDigit(65, 0))     // -1
print(findDigit(24, -8))    // -1
